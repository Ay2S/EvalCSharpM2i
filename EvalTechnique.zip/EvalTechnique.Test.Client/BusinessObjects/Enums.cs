﻿namespace EvalTechnique.Test.Client.BusinessObjects.Enums
{
    public enum StateFlag
    {
        None, Create, Update, Delete
    }

    public enum VideoType
    {
        All, Movie, Serie
    }
}
