﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace EvalTechnique.EBusiness
{
    // TODO DONE: Add xml serialization attributes (if required) to match VideoDataBase.xml format
    [DataContract]
    public class Episode : VideoDataBaseItem
    {
    }
}
